# -*- coding: utf-8 -*-
"""数据库初始化脚本：若目标库尚无业务表，则执行 db/init.sql 完成建库建表与灌数据。

在本地运行时读取 ../db/init.sql；在 Docker 容器中读取 /app/schema.sql
（由 Dockerfile 从 db/init.sql 拷贝而来）。脚本幂等：已初始化则跳过；
openGauss 容器启动较慢，脚本内置连接重试。
"""
import os
import sys
import time

import psycopg2

from config import DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD


def find_schema_file():
    candidates = [
        os.environ.get("SCHEMA_PATH"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "db", "init.sql"),
        "/app/schema.sql",
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return os.path.abspath(c)
    raise FileNotFoundError("未找到 schema 文件（db/init.sql 或 /app/schema.sql）")


def connect_with_retry(tries=30, delay=2):
    last_err = None
    for i in range(tries):
        try:
            return psycopg2.connect(
                host=DB_HOST, port=DB_PORT, dbname=DB_NAME,
                user=DB_USER, password=DB_PASSWORD,
            )
        except Exception as e:  # noqa: BLE001
            last_err = e
            print(f"[init_db] 连接数据库失败（第 {i+1}/{tries} 次），{delay}s 后重试：{e}")
            time.sleep(delay)
    raise last_err


def main():
    schema_file = find_schema_file()
    conn = connect_with_retry()
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute(
        "SELECT COUNT(*) FROM information_schema.tables "
        "WHERE table_schema='public' AND table_name='student'"
    )
    exists = cur.fetchone()[0] > 0
    if exists:
        print("[init_db] 业务表已存在，跳过初始化")
    else:
        with open(schema_file, encoding="utf-8") as f:
            sql = f.read()
        cur.execute(sql)
        print(f"[init_db] 已执行 {schema_file}，数据库初始化完成")
    conn.close()


if __name__ == "__main__":
    main()
