# -*- coding: utf-8 -*-
"""高校选课系统 —— Flask Web 应用（三层架构：表现层 / 业务逻辑层 / 数据层）。

角色：
  student   学生：浏览可选课程、选课、退课、查看课表与成绩
  teacher   教师：查看我的教学班、查看学生名单、录入成绩
  admin     管理员：维护院系 / 学生 / 教师 / 课程 / 开课班

后端通过 psycopg2 访问国产数据库 openGauss；核心业务规则
（容量、冲突、先修、学分上限）封装在数据库存储函数 fn_enroll 中。
"""
from functools import wraps

from flask import (Flask, flash, redirect, render_template, request,
                   session, url_for)

from config import SECRET_KEY
from db import call_fn, execute, query

app = Flask(__name__)
app.secret_key = SECRET_KEY

# 选课函数返回状态码 -> 中文提示
ENROLL_MSG = {
    0: "选课成功",
    1: "已选过该教学班",
    2: "该教学班人数已满",
    3: "上课时间冲突",
    4: "已选学分超过上限（30 学分）",
    5: "先修课程未通过，暂不能选修",
    6: "教学班不存在",
}


# ---------------------------------------------------------------
# 登录校验装饰器
# ---------------------------------------------------------------
def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if not session.get("user_id"):
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                flash("无权访问该页面", "error")
                return redirect(url_for("index"))
            return f(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------------
# 通用：登录 / 登出 / 首页路由
# ---------------------------------------------------------------
@app.route("/")
def index():
    role = session.get("role")
    if role == "student":
        return redirect(url_for("student_dashboard"))
    if role == "teacher":
        return redirect(url_for("teacher_dashboard"))
    if role == "admin":
        return redirect(url_for("admin_dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        role = request.form.get("role")
        uid = request.form.get("user_id", "").strip()
        pwd = request.form.get("password", "")

        table = {"student": "student", "teacher": "instructor", "admin": "admin"}.get(role)
        if not table:
            flash("请选择正确的角色", "error")
            return render_template("login.html")

        row = query(
            f"SELECT * FROM {table} WHERE "
            + ("student_id" if role == "student" else
               "instructor_id" if role == "teacher" else "admin_id")
            + " = %s AND password = %s",
            (uid, pwd),
            one=True,
        )
        if not row:
            flash("账号或密码错误", "error")
            return render_template("login.html")

        session["user_id"] = uid
        session["role"] = role
        session["name"] = row["name"]
        return redirect(url_for("index"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------
# 学生端（模块负责人 A）
# ---------------------------------------------------------------
@app.route("/student")
@login_required("student")
def student_dashboard():
    sid = session["user_id"]
    student = query("SELECT * FROM student WHERE student_id = %s", (sid,), one=True)
    schedule = query(
        "SELECT * FROM v_student_schedule WHERE student_id = %s ORDER BY semester, time_slot",
        (sid,),
    )
    total_credits = call_fn("fn_student_credits", (sid,))
    return render_template(
        "student/dashboard.html",
        student=student, schedule=schedule, total_credits=total_credits,
    )


@app.route("/student/enroll")
@login_required("student")
def student_enroll():
    sid = session["user_id"]
    sections = query(
        "SELECT * FROM v_section_info WHERE semester='2026秋' "
        "ORDER BY course_id, section_id"
    )
    # 已选教学班 id 集合，用于前端标注“已选”
    my = query(
        "SELECT section_id FROM enrollment WHERE student_id = %s", (sid,)
    )
    my_ids = {m["section_id"] for m in my}
    return render_template(
        "student/enroll.html", sections=sections, my_ids=my_ids
    )


@app.route("/student/enroll/<int:section_id>", methods=["POST"])
@login_required("student")
def student_enroll_action(section_id):
    sid = session["user_id"]
    code = int(call_fn("fn_enroll", (sid, section_id)))
    flash(ENROLL_MSG.get(code, "操作失败"), "success" if code == 0 else "error")
    return redirect(url_for("student_enroll"))


@app.route("/student/drop/<int:section_id>", methods=["POST"])
@login_required("student")
def student_drop_action(section_id):
    sid = session["user_id"]
    code = int(call_fn("fn_drop_course", (sid, section_id)))
    flash("退课成功" if code == 0 else "未找到选课记录", "success" if code == 0 else "error")
    return redirect(url_for("student_dashboard"))


# ---------------------------------------------------------------
# 教师端（模块负责人 B）
# ---------------------------------------------------------------
@app.route("/teacher")
@login_required("teacher")
def teacher_dashboard():
    tid = session["user_id"]
    teacher = query("SELECT * FROM instructor WHERE instructor_id = %s", (tid,), one=True)
    sections = query(
        "SELECT * FROM v_section_info WHERE instructor_id = %s "
        "ORDER BY semester, section_id",
        (tid,),
    )
    return render_template("teacher/dashboard.html", teacher=teacher, sections=sections)


@app.route("/teacher/section/<int:section_id>")
@login_required("teacher")
def teacher_roster(section_id):
    section = query(
        "SELECT * FROM v_section_info WHERE section_id = %s", (section_id,), one=True
    )
    roster = query(
        "SELECT * FROM v_section_roster WHERE section_id = %s ORDER BY student_id",
        (section_id,),
    )
    return render_template("teacher/roster.html", section=section, roster=roster)


@app.route("/teacher/grade", methods=["POST"])
@login_required("teacher")
def teacher_grade():
    enrollment_id = request.form.get("enrollment_id")
    grade = request.form.get("grade", "").strip()
    if not grade:
        flash("请输入成绩", "error")
    else:
        try:
            execute(
                "UPDATE enrollment SET grade = %s WHERE enrollment_id = %s",
                (float(grade), int(enrollment_id)),
            )
            flash("成绩录入成功", "success")
        except Exception as e:
            flash(f"成绩录入失败：{e}", "error")
    section_id = request.form.get("section_id")
    return redirect(url_for("teacher_roster", section_id=section_id))


# ---------------------------------------------------------------
# 管理员端（模块负责人 C）
# ---------------------------------------------------------------
@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    stats = {
        "students": query("SELECT COUNT(*) AS n FROM student", one=True)["n"],
        "instructors": query("SELECT COUNT(*) AS n FROM instructor", one=True)["n"],
        "courses": query("SELECT COUNT(*) AS n FROM course", one=True)["n"],
        "sections": query("SELECT COUNT(*) AS n FROM section", one=True)["n"],
        "enrollments": query("SELECT COUNT(*) AS n FROM enrollment", one=True)["n"],
        "departments": query("SELECT COUNT(*) AS n FROM department", one=True)["n"],
    }
    return render_template("admin/dashboard.html", stats=stats)


@app.route("/admin/departments", methods=["GET", "POST"])
@login_required("admin")
def admin_departments():
    if request.method == "POST":
        name = request.form.get("dept_name", "").strip()
        building = request.form.get("building", "").strip()
        if name:
            execute("INSERT INTO department (dept_name, building) VALUES (%s, %s)",
                    (name, building))
            flash("院系添加成功", "success")
        return redirect(url_for("admin_departments"))
    rows = query("SELECT * FROM department ORDER BY dept_id")
    return render_template("admin/departments.html", rows=rows)


@app.route("/admin/students", methods=["GET", "POST"])
@login_required("admin")
def admin_students():
    if request.method == "POST":
        sid = request.form.get("student_id", "").strip()
        name = request.form.get("name", "").strip()
        dept_id = request.form.get("dept_id") or None
        gender = request.form.get("gender", "").strip() or None
        year = request.form.get("enroll_year") or None
        if sid and name:
            execute(
                "INSERT INTO student (student_id, name, dept_id, gender, enroll_year) "
                "VALUES (%s, %s, %s, %s, %s)",
                (sid, name, dept_id, gender, year),
            )
            flash("学生添加成功", "success")
        return redirect(url_for("admin_students"))
    rows = query(
        "SELECT s.*, d.dept_name FROM student s LEFT JOIN department d "
        "ON s.dept_id = d.dept_id ORDER BY s.student_id"
    )
    depts = query("SELECT * FROM department ORDER BY dept_id")
    return render_template("admin/students.html", rows=rows, depts=depts)


@app.route("/admin/instructors", methods=["GET", "POST"])
@login_required("admin")
def admin_instructors():
    if request.method == "POST":
        iid = request.form.get("instructor_id", "").strip()
        name = request.form.get("name", "").strip()
        dept_id = request.form.get("dept_id") or None
        title = request.form.get("title", "").strip() or None
        if iid and name:
            execute(
                "INSERT INTO instructor (instructor_id, name, dept_id, title) "
                "VALUES (%s, %s, %s, %s)",
                (iid, name, dept_id, title),
            )
            flash("教师添加成功", "success")
        return redirect(url_for("admin_instructors"))
    rows = query(
        "SELECT i.*, d.dept_name FROM instructor i LEFT JOIN department d "
        "ON i.dept_id = d.dept_id ORDER BY i.instructor_id"
    )
    depts = query("SELECT * FROM department ORDER BY dept_id")
    return render_template("admin/instructors.html", rows=rows, depts=depts)


@app.route("/admin/courses", methods=["GET", "POST"])
@login_required("admin")
def admin_courses():
    if request.method == "POST":
        cid = request.form.get("course_id", "").strip()
        title = request.form.get("title", "").strip()
        dept_id = request.form.get("dept_id") or None
        credits = request.form.get("credits") or None
        if cid and title:
            execute(
                "INSERT INTO course (course_id, title, dept_id, credits) "
                "VALUES (%s, %s, %s, %s)",
                (cid, title, dept_id, credits),
            )
            flash("课程添加成功", "success")
        return redirect(url_for("admin_courses"))
    rows = query(
        "SELECT c.*, d.dept_name FROM course c LEFT JOIN department d "
        "ON c.dept_id = d.dept_id ORDER BY c.course_id"
    )
    depts = query("SELECT * FROM department ORDER BY dept_id")
    return render_template("admin/courses.html", rows=rows, depts=depts)


@app.route("/admin/sections", methods=["GET", "POST"])
@login_required("admin")
def admin_sections():
    if request.method == "POST":
        course_id = request.form.get("course_id", "").strip()
        semester = request.form.get("semester", "").strip()
        year = request.form.get("year") or None
        instructor_id = request.form.get("instructor_id", "").strip()
        classroom = request.form.get("classroom", "").strip()
        time_slot = request.form.get("time_slot", "").strip()
        capacity = request.form.get("capacity") or None
        if course_id and semester:
            execute(
                "INSERT INTO section (course_id, semester, year, instructor_id, "
                "classroom, time_slot, capacity) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (course_id, semester, year, instructor_id, classroom, time_slot, capacity),
            )
            flash("开课班添加成功", "success")
        return redirect(url_for("admin_sections"))
    rows = query(
        "SELECT s.*, c.title AS course_title, i.name AS instructor_name "
        "FROM section s LEFT JOIN course c ON s.course_id = c.course_id "
        "LEFT JOIN instructor i ON s.instructor_id = i.instructor_id "
        "ORDER BY s.section_id"
    )
    courses = query("SELECT * FROM course ORDER BY course_id")
    instructors = query("SELECT * FROM instructor ORDER BY instructor_id")
    return render_template(
        "admin/sections.html", rows=rows, courses=courses, instructors=instructors
    )


@app.route("/admin/delete/<string:kind>/<string:pk>", methods=["POST"])
@login_required("admin")
def admin_delete(kind, pk):
    mapping = {
        "department": ("department", "dept_id"),
        "student": ("student", "student_id"),
        "instructor": ("instructor", "instructor_id"),
        "course": ("course", "course_id"),
        "section": ("section", "section_id"),
    }
    if kind in mapping:
        table, col = mapping[kind]
        try:
            execute(f"DELETE FROM {table} WHERE {col} = %s", (pk,))
            flash("删除成功", "success")
        except Exception as e:
            flash(f"删除失败（存在关联数据）：{e}", "error")
    return redirect(request.referrer or url_for("admin_dashboard"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
