# -*- coding: utf-8 -*-
"""数据库访问封装：基于 psycopg2 访问 openGauss（兼容 PostgreSQL 协议）。"""
import psycopg2
import psycopg2.extras

from config import DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD


def get_conn():
    """获取数据库连接。"""
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
    )


def query(sql, params=None, one=False):
    """查询：返回字典行（或单行字典）。"""
    conn = get_conn()
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(sql, params or ())
        rows = cur.fetchone() if one else cur.fetchall()
        conn.commit()  # 提交事务：SELECT 内调用存储函数做的写操作（如 fn_enroll）需提交才生效
        return rows
    finally:
        conn.close()


def execute(sql, params=None):
    """执行写操作：自动提交，异常时回滚。"""
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute(sql, params or ())
        conn.commit()
        return cur.rowcount
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def call_fn(name, params):
    """调用数据库函数并返回标量结果，例如 call_fn('fn_enroll', (sid, secid))。"""
    placeholders = ",".join(["%s"] * len(params))
    sql = f"SELECT {name}({placeholders})"
    row = query(sql, params, one=True)
    return list(row.values())[0] if row else None
