# -*- coding: utf-8 -*-
"""应用配置：所有可配置项均通过环境变量注入，便于 Docker 部署。"""
import os

DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "course_selection")
DB_USER = os.getenv("DB_USER", "omm")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Course@12345")

SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key-change-me")
