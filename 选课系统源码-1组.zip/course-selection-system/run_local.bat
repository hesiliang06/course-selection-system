@echo off
rem 高校选课系统 —— 本地启动（连接虚拟机里的 openGauss）
rem 双击本文件即可启动，然后浏览器访问 http://localhost:5000
cd /d "%~dp0app"
set DB_HOST=192.168.100.31
set DB_PORT=26000
set DB_NAME=course_selection
set DB_USER=student
set DB_PASSWORD=Student@2026
python app.py
