-- ============================================================
-- 高校选课系统 —— 数据库设计与初始化脚本
-- 目标数据库：openGauss 6.0（兼容 PostgreSQL 协议）
-- 数据库名  ：course_selection
-- 说明：本脚本可重复执行（先 DROP 再 CREATE），用于
--       1) gsql 手工导入已有 openGauss 实例；
--       2) 由应用容器启动时自动初始化。
-- ============================================================

-- ---------------- 清理旧对象（保证脚本可重复执行） ----------------
DROP VIEW IF EXISTS v_section_info CASCADE;
DROP VIEW IF EXISTS v_student_schedule CASCADE;
DROP VIEW IF EXISTS v_section_roster CASCADE;
DROP TABLE IF EXISTS enrollment CASCADE;
DROP TABLE IF EXISTS section CASCADE;
DROP TABLE IF EXISTS prereq CASCADE;
DROP TABLE IF EXISTS course CASCADE;
DROP TABLE IF EXISTS instructor CASCADE;
DROP TABLE IF EXISTS admin CASCADE;
DROP TABLE IF EXISTS student CASCADE;
DROP TABLE IF EXISTS department CASCADE;
DROP FUNCTION IF EXISTS trg_enroll_check() CASCADE;
DROP FUNCTION IF EXISTS trg_enroll_after_delete() CASCADE;
DROP FUNCTION IF EXISTS fn_student_credits(VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS fn_enroll(VARCHAR, INT) CASCADE;
DROP FUNCTION IF EXISTS fn_drop_course(VARCHAR, INT) CASCADE;

-- ============================================================
-- 一、基础表（逻辑结构）
-- ============================================================

-- 1. 院系表
CREATE TABLE department (
    dept_id     SERIAL PRIMARY KEY,
    dept_name   VARCHAR(50) NOT NULL UNIQUE,
    building    VARCHAR(30)
);

-- 2. 学生表
CREATE TABLE student (
    student_id  VARCHAR(8) PRIMARY KEY,          -- 学号
    name        VARCHAR(40) NOT NULL,            -- 姓名
    dept_id     INT REFERENCES department(dept_id),  -- 所属院系
    gender      VARCHAR(4) CHECK (gender IN ('男','女')),
    enroll_year INT,                             -- 入学年份
    password    VARCHAR(64) NOT NULL DEFAULT '123456'
);

-- 3. 教师表
CREATE TABLE instructor (
    instructor_id VARCHAR(6) PRIMARY KEY,        -- 工号
    name          VARCHAR(40) NOT NULL,
    dept_id       INT REFERENCES department(dept_id),
    title         VARCHAR(20),                   -- 职称
    password      VARCHAR(64) NOT NULL DEFAULT '123456'
);

-- 4. 管理员表
CREATE TABLE admin (
    admin_id VARCHAR(6) PRIMARY KEY,
    name     VARCHAR(40) NOT NULL,
    password VARCHAR(64) NOT NULL DEFAULT 'admin123'
);

-- 5. 课程表
CREATE TABLE course (
    course_id VARCHAR(8) PRIMARY KEY,            -- 课程号
    title     VARCHAR(60) NOT NULL,              -- 课程名
    dept_id   INT REFERENCES department(dept_id),-- 开课院系
    credits   NUMERIC(3,1) NOT NULL CHECK (credits > 0)  -- 学分
);

-- 6. 先修课程表（课程之间的先修依赖，多对多）
CREATE TABLE prereq (
    course_id  VARCHAR(8) REFERENCES course(course_id),
    prereq_id  VARCHAR(8) REFERENCES course(course_id),
    PRIMARY KEY (course_id, prereq_id)
);

-- 7. 开课班（教学班）表：同一门课可以开多个教学班
CREATE TABLE section (
    section_id    SERIAL PRIMARY KEY,            -- 教学班号
    course_id     VARCHAR(8) REFERENCES course(course_id),
    semester      VARCHAR(11) NOT NULL,          -- 学期（如 2026秋）
    year          INT NOT NULL,                  -- 年份
    instructor_id VARCHAR(6) REFERENCES instructor(instructor_id), -- 授课教师
    classroom     VARCHAR(30),                   -- 教室
    time_slot     VARCHAR(20),                   -- 上课时间（用于冲突检测）
    capacity      INT NOT NULL CHECK (capacity > 0),  -- 容量
    enrolled      INT NOT NULL DEFAULT 0 CHECK (enrolled >= 0)  -- 已选人数
);

-- 8. 选课记录表（学生与教学班的多对多关系）
CREATE TABLE enrollment (
    enrollment_id SERIAL PRIMARY KEY,
    student_id    VARCHAR(8) REFERENCES student(student_id),
    section_id    INT REFERENCES section(section_id),
    grade         NUMERIC(4,1),                  -- 成绩（NULL 表示尚未录入）
    enroll_time   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (student_id, section_id)              -- 防止重复选同一教学班
);

-- ============================================================
-- 二、索引（优化查询性能）
-- ============================================================
CREATE INDEX idx_enrollment_student ON enrollment(student_id);
CREATE INDEX idx_enrollment_section ON enrollment(section_id);
CREATE INDEX idx_section_course ON section(course_id, semester, year);
CREATE INDEX idx_course_dept ON course(dept_id);

-- ============================================================
-- 三、视图（封装常用查询）
-- ============================================================

-- 3.1 可选教学班信息（课程名、教师、教室、时间、容量、余量）
CREATE OR REPLACE VIEW v_section_info AS
SELECT s.section_id, s.course_id, c.title AS course_title, c.credits,
       s.semester, s.year, s.instructor_id, i.name AS instructor_name, s.classroom, s.time_slot,
       s.capacity, s.enrolled, (s.capacity - s.enrolled) AS remain,
       d.dept_name
FROM section s
JOIN course c ON s.course_id = c.course_id
JOIN instructor i ON s.instructor_id = i.instructor_id
JOIN department d ON c.dept_id = d.dept_id;

-- 3.2 学生课表视图（某学生已选的全部课程）
CREATE OR REPLACE VIEW v_student_schedule AS
SELECT e.student_id, e.enrollment_id, s.section_id, c.course_id, c.title,
       c.credits, s.semester, s.year, i.name AS instructor_name,
       s.classroom, s.time_slot, e.grade
FROM enrollment e
JOIN section s ON e.section_id = s.section_id
JOIN course c ON s.course_id = c.course_id
JOIN instructor i ON s.instructor_id = i.instructor_id;

-- 3.3 教学班学生名单视图
CREATE OR REPLACE VIEW v_section_roster AS
SELECT s.section_id, e.enrollment_id, st.student_id, st.name AS student_name,
       st.dept_id, e.grade
FROM section s
JOIN enrollment e ON s.section_id = e.section_id
JOIN student st ON e.student_id = st.student_id;

-- ============================================================
-- 四、触发器（维护开课班已选人数，保证数据一致性）
-- ============================================================

-- 4.1 插入选课记录前：检查容量并累加已选人数
CREATE OR REPLACE FUNCTION trg_enroll_check() RETURNS TRIGGER AS $$
DECLARE
    v_cap INT;
    v_enr INT;
BEGIN
    SELECT capacity, enrolled INTO v_cap, v_enr
    FROM section WHERE section_id = NEW.section_id;
    IF v_enr >= v_cap THEN
        RAISE EXCEPTION '教学班人数已满';
    END IF;
    UPDATE section SET enrolled = enrolled + 1 WHERE section_id = NEW.section_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 4.2 删除选课记录后：已选人数减一
CREATE OR REPLACE FUNCTION trg_enroll_after_delete() RETURNS TRIGGER AS $$
BEGIN
    UPDATE section SET enrolled = enrolled - 1 WHERE section_id = OLD.section_id;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_enroll_before_insert
BEFORE INSERT ON enrollment
FOR EACH ROW EXECUTE PROCEDURE trg_enroll_check();

CREATE TRIGGER trg_enroll_after_delete
AFTER DELETE ON enrollment
FOR EACH ROW EXECUTE PROCEDURE trg_enroll_after_delete();

-- ============================================================
-- 五、存储函数（封装核心业务规则：选课 / 退课 / 学分）
-- ============================================================

-- 5.1 计算学生当前已选课程的总学分
CREATE OR REPLACE FUNCTION fn_student_credits(p_student_id VARCHAR)
RETURNS NUMERIC AS $$
DECLARE
    v_total NUMERIC;
BEGIN
    SELECT COALESCE(SUM(c.credits), 0) INTO v_total
    FROM enrollment e
    JOIN section s ON e.section_id = s.section_id
    JOIN course c ON s.course_id = c.course_id
    WHERE e.student_id = p_student_id;
    RETURN v_total;
END;
$$ LANGUAGE plpgsql;

-- 5.2 选课：返回状态码（0 成功）
--     1 已选过   2 人数已满  3 时间冲突  4 学分超上限
--     5 先修课未通过  6 教学班不存在
CREATE OR REPLACE FUNCTION fn_enroll(p_student_id VARCHAR, p_section_id INT)
RETURNS INT AS $$
DECLARE
    v_sec      RECORD;
    v_credits  NUMERIC;
    v_total    NUMERIC;
    v_exists   INT;
    v_conflict INT;
    v_prereq   INT;
BEGIN
    SELECT * INTO v_sec FROM section WHERE section_id = p_section_id;
    IF NOT FOUND THEN
        RETURN 6;   -- 教学班不存在
    END IF;

    SELECT COUNT(*) INTO v_exists FROM enrollment
    WHERE student_id = p_student_id AND section_id = p_section_id;
    IF v_exists > 0 THEN
        RETURN 1;   -- 已选过
    END IF;

    IF v_sec.enrolled >= v_sec.capacity THEN
        RETURN 2;   -- 人数已满
    END IF;

    SELECT COUNT(*) INTO v_conflict
    FROM enrollment e JOIN section s ON e.section_id = s.section_id
    WHERE e.student_id = p_student_id
      AND s.semester = v_sec.semester AND s.year = v_sec.year
      AND s.time_slot = v_sec.time_slot AND s.section_id <> p_section_id;
    IF v_conflict > 0 THEN
        RETURN 3;   -- 时间冲突
    END IF;

    SELECT credits INTO v_credits FROM course WHERE course_id = v_sec.course_id;
    SELECT fn_student_credits(p_student_id) INTO v_total;
    IF v_total + v_credits > 30 THEN
        RETURN 4;   -- 学分超上限
    END IF;

    SELECT COUNT(*) INTO v_prereq
    FROM prereq p
    WHERE p.course_id = v_sec.course_id
      AND p.prereq_id NOT IN (
          SELECT c.course_id
          FROM enrollment e JOIN section s ON e.section_id = s.section_id
          JOIN course c ON s.course_id = c.course_id
          WHERE e.student_id = p_student_id AND e.grade IS NOT NULL AND e.grade >= 60
      );
    IF v_prereq > 0 THEN
        RETURN 5;   -- 先修课未通过
    END IF;

    INSERT INTO enrollment(student_id, section_id) VALUES (p_student_id, p_section_id);
    RETURN 0;       -- 成功
END;
$$ LANGUAGE plpgsql;

-- 5.3 退课：返回状态码（0 成功，1 未找到选课记录）
CREATE OR REPLACE FUNCTION fn_drop_course(p_student_id VARCHAR, p_section_id INT)
RETURNS INT AS $$
DECLARE
    v_id INT;
BEGIN
    SELECT enrollment_id INTO v_id FROM enrollment
    WHERE student_id = p_student_id AND section_id = p_section_id;
    IF NOT FOUND THEN
        RETURN 1;
    END IF;
    DELETE FROM enrollment WHERE enrollment_id = v_id;
    RETURN 0;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- 六、种子数据（演示用）
-- ============================================================

INSERT INTO department (dept_id, dept_name, building) VALUES
 (1, '计算机学院', '逸夫楼'),
 (2, '数学学院', '理科楼'),
 (3, '外国语学院', '外语楼');
SELECT setval('department_dept_id_seq', 3);

INSERT INTO instructor (instructor_id, name, dept_id, title) VALUES
 ('T1001', '王建国', 1, '教授'),
 ('T1002', '李芳',   1, '副教授'),
 ('T1003', '孙浩',   1, '讲师'),
 ('T2001', '张伟',   2, '教授'),
 ('T3001', '刘洋',   3, '讲师');

INSERT INTO student (student_id, name, dept_id, gender, enroll_year) VALUES
 ('20240001', '何思靓', 1, '女', 2024),
 ('20240002', '陈晓',   1, '男', 2024),
 ('20240003', '李华',   2, '男', 2024),
 ('20240004', '王芳',   3, '女', 2024),
 ('20240005', '赵强',   1, '男', 2024);

INSERT INTO admin (admin_id, name) VALUES ('A0001', '系统管理员');

INSERT INTO course (course_id, title, dept_id, credits) VALUES
 ('CS001', '程序设计基础', 1, 4.0),
 ('CS002', '数据结构',     1, 4.0),
 ('CS003', '数据库系统',   1, 3.5),
 ('CS004', '操作系统',     1, 4.0),
 ('CS005', '计算机网络',   1, 3.0),
 ('MA001', '高等数学',     2, 5.0),
 ('MA002', '线性代数',     2, 3.0),
 ('EN001', '大学英语',     3, 3.0);

INSERT INTO prereq (course_id, prereq_id) VALUES
 ('CS002', 'CS001'),
 ('CS003', 'CS002'),
 ('CS004', 'CS002'),
 ('CS005', 'CS002'),
 ('MA002', 'MA001');

-- 2026秋 本学期开课班（容量故意设小，便于演示“满员”限制）
INSERT INTO section (section_id, course_id, semester, year, instructor_id, classroom, time_slot, capacity, enrolled) VALUES
 (1, 'CS003', '2026秋', 2026, 'T1001', '逸夫楼201', '周一3-4节', 3,  0),
 (2, 'CS002', '2026秋', 2026, 'T1001', '逸夫楼301', '周一1-2节', 3,  0),
 (3, 'CS001', '2026秋', 2026, 'T1002', '逸夫楼202', '周二1-2节', 40, 0),
 (4, 'MA001', '2026秋', 2026, 'T2001', '理科楼101', '周三1-2节', 50, 0),
 (5, 'EN001', '2026秋', 2026, 'T3001', '外语楼201', '周四3-4节', 30, 0),
 (6, 'CS004', '2026秋', 2026, 'T1002', '逸夫楼303', '周二3-4节', 3,  0),
 (7, 'CS005', '2026秋', 2026, 'T1001', '逸夫楼305', '周五1-2节', 35, 0),
 -- 上一学期（2026春）历史开课班，用于演示“先修课已通过”
 (100, 'CS001', '2026春', 2026, 'T1002', '逸夫楼202', '周二1-2节', 40, 0),
 (101, 'CS002', '2026春', 2026, 'T1001', '逸夫楼301', '周一1-2节', 40, 0);
SELECT setval('section_section_id_seq', 101);

-- 陈晓上学期已修完“程序设计基础”“数据结构”（成绩 >= 60），本学期可继续选后续课程
INSERT INTO enrollment (student_id, section_id, grade) VALUES
 ('20240002', 100, 85.0),
 ('20240002', 101, 90.0),
 ('20240002', 1, NULL),
 ('20240003', 4, NULL),
 ('20240004', 5, NULL);
SELECT setval('enrollment_enrollment_id_seq', 5);

-- 用实际选课记录校正“已选人数”，与触发器维护逻辑保持一致
UPDATE section s
SET enrolled = (SELECT COUNT(*) FROM enrollment e WHERE e.section_id = s.section_id);
