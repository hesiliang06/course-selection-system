# 高校选课系统（基于 openGauss + Flask + Docker）

一个面向高校教务场景的 **Web 选课系统**，采用经典三层架构：

- **表现层**：HTML / CSS / JavaScript（Jinja2 模板渲染，无前端构建步骤）
- **业务逻辑层**：Python Flask（路由、登录、选课/退课/成绩等业务）
- **数据层**：国产数据库 **openGauss 6.0**（兼容 PostgreSQL 协议，使用 `psycopg2` 访问）

核心业务规则（容量限制、时间冲突、先修课、学分上限）封装在数据库的
**视图 / 存储函数 / 触发器** 中，体现“数据库设计、部署、访问”这一考核重点。

---

## 一、功能与角色

| 角色 | 功能 |
|---|---|
| 学生 | 登录、浏览可选课程、选课、退课、查看课表与已选学分 |
| 教师 | 登录、查看我的教学班、查看学生名单、录入成绩 |
| 管理员 | 登录、维护院系 / 学生 / 教师 / 课程 / 开课班（增删） |

选课由数据库存储函数 `fn_enroll` 统一校验：
已选重复、人数已满、时间冲突、学分超上限、先修课未通过。

---

## 二、目录结构

```
34 select system/
├── README.md                 # 本文件
├── docker-compose.yml        # 一键部署：openGauss + Web 应用
├── .env.example              # 连接外部 openGauss 时的环境变量示例
├── db/
│   └── init.sql              # 数据库设计与初始化脚本（建表/索引/视图/触发器/存储函数/种子数据）
└── app/
    ├── Dockerfile            # Web 应用镜像
    ├── requirements.txt      # Python 依赖
    ├── config.py             # 配置（从环境变量读取）
    ├── db.py                 # 数据库访问封装（psycopg2）
    ├── init_db.py            # 启动时自动初始化数据库（幂等）
    ├── app.py                # Flask 主程序（全部路由与业务逻辑）
    ├── schema.sql            # 由 Dockerfile 从 db/init.sql 拷贝（容器内使用）
    ├── templates/            # Jinja2 模板（student/teacher/admin 三端）
    └── static/style.css      # 样式
```

---

## 三、快速部署（Docker，一键启动）

前置条件：已安装 Docker 与 Docker Compose。

```bash
cd "34 select system"
docker compose up -d --build
```

启动完成后：

- 浏览器访问 **http://localhost:5000**
- openGauss 数据库端口映射到宿主机 **15432**（容器内 5432）

首次启动时，`db` 容器会初始化数据库；`web` 容器启动前执行
`init_db.py`，自动完成建表与灌数据（幂等，重复启动不会重复初始化）。

查看日志：

```bash
docker compose logs -f web      # Web 应用日志
docker compose logs -f db       # 数据库日志
```

停止 / 清理：

```bash
docker compose down             # 停止（保留数据卷）
docker compose down -v          # 停止并删除数据卷（重置数据库）
```

---

## 四、连接已有 openGauss 实例（本地运行）

如果你已经有一台装了 openGauss 的虚拟机（例如 `192.168.100.31`），
也可以让 Web 应用直接连它，而不用 Docker 里的数据库：

```bash
# 1. 在 openGauss 中创建业务数据库并导入脚本
gsql -d postgres -c "CREATE DATABASE course_selection;"
gsql -d course_selection -f db/init.sql

# 2. 配置连接并启动
cd app
pip install -r requirements.txt
export DB_HOST=192.168.100.31 DB_PORT=26000 \
       DB_NAME=course_selection DB_USER=student DB_PASSWORD='student@ustb2020'
python app.py        # 访问 http://localhost:5000
```

> 端口、用户名、密码按你自己 openGauss 实例的实际值填写。

---

## 五、演示账号（种子数据）

| 角色 | 账号 | 密码 |
|---|---|---|
| 学生 | `20240001`（何思靓） | `123456` |
| 学生 | `20240002`（陈晓，已修完先修课） | `123456` |
| 教师 | `T1001`（王建国） | `123456` |
| 管理员 | `A0001` | `admin123` |

---

## 六、小组分工（A / B / C 三人）

| 成员 | 负责模块 | 主要工作 |
|---|---|---|
| **A（负责人）** | 数据库设计 + 学生端 | E-R 建模、建表/索引/视图/存储函数/触发器；学生登录、选课、退课、课表 |
| **B** | 教师端 | 教师登录、我的教学班、学生名单查看、成绩录入 |
| **C** | 管理员端 + 部署 | 管理员登录、院系/学生/教师/课程/开课班管理；Dockerfile、docker-compose、容器化部署 |

> 报告中“详细设计”和“项目实现”两节，每人只写自己负责的模块；其余六节全组共用。

---

## 七、数据库设计要点

- **8 张表**：`department`（院系）、`student`（学生）、`instructor`（教师）、
  `admin`（管理员）、`course`（课程）、`prereq`（先修）、`section`（开课班）、
  `enrollment`（选课记录）。
- **约束**：主键、外键、`UNIQUE`（学生-教学班唯一、院系名唯一）、
  `CHECK`（性别、学分>0、容量>0、已选人数>=0）。
- **索引**：选课记录按学生/教学班建索引，开课班按课程+学期+年份建索引。
- **3 个视图**：`v_section_info`（可选教学班）、`v_student_schedule`（学生课表）、
  `v_section_roster`（教学班名单）。
- **3 个存储函数**：`fn_enroll`（选课，含 5 类业务校验）、`fn_drop_course`（退课）、
  `fn_student_credits`（已选学分）。
- **2 个触发器**：插入选课记录前校验容量并累加人数、删除记录后递减人数。
